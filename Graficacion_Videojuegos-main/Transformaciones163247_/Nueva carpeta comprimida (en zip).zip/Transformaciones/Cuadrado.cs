﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transformaciones
{
    internal class Cuadrado: Figura
    {
        Attribute attribute;
        
        public Cuadrado(int size, Point location) {
            size = size * 100;
            int sides = 4;

            //for(int i = 0; i < sides; i++)
            //{
               
            //    this.AddPoint(new Point(0, 0));
            //}
            CalculatePoints(size,location);
        }

        public override void CalculatePoints(int size, Point location)
        {
            this.AddPoint(new Point(location.X - (int)size / 2, location.Y - (int)size / 2));
            this.AddPoint(new Point(location.X + (int)size / 2, location.Y - (int)size / 2));
            this.AddPoint(new Point(location.X + (int)size / 2, location.Y + (int)size / 2));
            this.AddPoint(new Point(location.X - (int)size / 2, location.Y + (int)size / 2));

        }

        public override Point getCentroid() //esto esta mañ!!
        {
            return new Point(size * 100 / 2, size * 100 / 2);
        }
    }
}
