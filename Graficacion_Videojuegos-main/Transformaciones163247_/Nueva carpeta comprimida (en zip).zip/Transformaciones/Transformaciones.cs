﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transformaciones
{
    internal class Transformaciones
    {

        public static Point Translacion(Point p,int transX, int transY)
        {
            p.X = p.X + transX;
            p.Y = p.Y + transY;

            return p;
        }

        public static void Rotacion(Point p, double degree)
        {
             
        }

    }
}
